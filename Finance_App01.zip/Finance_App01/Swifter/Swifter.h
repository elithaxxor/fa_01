//
//  Swifter.h
//  Swifter
//
//  Created by a-robota on 5/30/22.
//

#import <Foundation/Foundation.h>

//! Project version number for Swifter.
FOUNDATION_EXPORT double SwifterVersionNumber;

//! Project version string for Swifter.
FOUNDATION_EXPORT const unsigned char SwifterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Swifter/PublicHeader.h>


