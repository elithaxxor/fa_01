//
//  ViewController.swift
//  Finance_App01
//
//  Created by a-robota on 5/30/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

