////
////  AppDelegate.swift
////  pdfScanner
////
////  Created by a-robota on 4/4/22.
////
//
//import Foundation
////
////  AppDelegate.swift
////  PDFviewer
////
////  Created by a-robota on 4/4/22.
////
//
//import UIKit
//
//
//// DELEGATE PAGE--> MANAGES STATE
//class AppDelegate: UIResponder, UIApplicationDelegate {
//    
//    func application(_ application: UIApplication, didFinishLaunchingWithOptions  launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
//        return true
//    }
//    
//    func application (_ application: UIApplication, configurationForConnecting  connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
//        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
//}
//}
