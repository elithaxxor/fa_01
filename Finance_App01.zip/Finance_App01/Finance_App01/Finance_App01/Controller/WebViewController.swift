//
//  WebViewViewController.swift
//  
//
//  Created by a-robota on 6/2/22.
//


import UIKit
import SwiftUI
import WebKit

// https://finance.yahoo.com/quote/AAPL?p=AAPL&.tsrc=fin-srch

// TODO:
class WebViewController: UIViewController, WKNavigationDelegate, WKUIDelegate {

    @IBOutlet weak var webView : WKWebView? {
        didSet {
            let preferences = WKPreferences()
            preferences.javaScriptEnabled = true
            let configuration = WKWebViewConfiguration()
            configuration.preferences = preferences
            let webView = WKWebView(frame: .zero, configuration: configuration)
            parseUIView(webView)
        }
    }

    @IBAction func textView (_sender: UITextField) {
        print("[!] Sender Is Searching for webView-news ")

    }
    @IBAction func searchBtn (_sender: UIButton) {
        print("[!] Sender Is Searching for webView-news ")

    }

    let backupURL : String = "https://finance.yahoo.com/quote/AAPL?p=AAPL&.tsrc=fin-srch"


    private let url : String?
    var urlStr : String?
    var urlStr0 : String?

    var passedSearch00 : String?
    var passedSearch01 : String?

    init(url: String, urlStr: String, urlStr0: String) {
        self.url = url
        self.urlStr = urlStr
        self.urlStr0 = urlStr0

        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidLoad() {
        super.viewDidLoad()
            //view.addSubview(parseUIView(webView!))
    }

    //    override func viewwDidLayoutSubviws() {
    //        super.viewDidLayoutSubviews()
    //        view.addSubview(webView!)
    //    }


    func parseUIView(_ uiView: WKWebView) {
        let requestURL = URLRequest(url: URL(string: self.url ?? self.backupURL)!)
        print("[!] Starting Request on \(requestURL)")
        uiView.load(requestURL)
    }
}


enum webViewVCerr {
    case parsingUrlerr
}
extension webViewVCerr {
    public var webViewVCerrDescript : String {
        switch self {
            case .parsingUrlerr : return "[-] Error in parsing URL  "
        }
    }
}

//let webView = WebView()



// MARK: - Navigation
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//
//    }




