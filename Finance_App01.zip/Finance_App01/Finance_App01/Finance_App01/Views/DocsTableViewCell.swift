//
//  DocsTableViewCell.swift
//  Finance_App01
//
//  Created by a-robota on 6/1/22.
//

import UIKit

class DocsTableViewCell: UITableViewCell {

    private var docsCellResults : [docsResults] = []
    private var docsCellResults00 : [FinanceDocs] = []

    @IBOutlet weak var titleLabel : UILabel!
    @IBOutlet weak var bodyLabel : UILabel!


    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        docsCellResults
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }



    func configure(with : docsResults){
        titleLabel.text = " \(FinanceDocs.ID.self)"
        bodyLabel.text = "\(FinanceDocs.codingKeys.self)"

    }

}
