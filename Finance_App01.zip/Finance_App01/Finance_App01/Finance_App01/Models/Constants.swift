//
//  Constants.swift
//  Financial_Calc_II
//
//  Created by a-robota on 4/20/22.
//

import Foundation


struct K {
    let searchResults: SearchResults
    //let timeSeriesMonthlyAdjusted: TimeSeriesMonthlyAdjusted

}


 
