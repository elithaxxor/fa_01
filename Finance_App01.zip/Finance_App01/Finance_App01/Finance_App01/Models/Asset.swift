//
//  Assets.swift
//  Financial_Calc_II
//
//  Created by a-robota on 5/23/22.
//

import Foundation

// For API Datastructure 
struct Asset {
    let searchResults: SearchResult
    let TimeByMonthModel: TimeByMonthModel
}
