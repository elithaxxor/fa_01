//
//  businessCardIIApp.swift
//  businessCardII
//
//  Created by a-robota on 4/19/22.


// TODO: MOVE THIS TO APPDELEGATE 
import SwiftUI

// @main
struct businessCardIIApp: App {
    var body: some Scene {
        WindowGroup {
            InfoView(text: "nobodylikesme", imageName: "wsb")
        }
    }
}
